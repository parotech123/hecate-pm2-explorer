import{a as t}from"../chunks/entry.CDX8DWaV.js";export{t as start};
