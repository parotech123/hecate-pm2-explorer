import{a as t}from"../chunks/entry.D8k8hsY6.js";export{t as start};
